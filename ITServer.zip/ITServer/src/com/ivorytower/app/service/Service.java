package com.ivorytower.app.service;

/**
 * 		顶层service接口
 * 		author            ：      		xionglei   
 * 		createtime        ：  		2013-8-7 下午5:22:52
 */
public interface Service {

}
