package com.ivorytower.app.dao;

/**
 * 		顶层Dao接口
 * 		author            ：      		xionglei   
 * 		createtime        ：  		2013-8-7 下午5:24:44
 */
public interface Dao{

}
